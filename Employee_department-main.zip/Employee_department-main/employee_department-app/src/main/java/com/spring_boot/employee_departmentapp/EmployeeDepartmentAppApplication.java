package com.spring_boot.employee_departmentapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeDepartmentAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeDepartmentAppApplication.class, args);
	}

}
