package com.spring_boot.employee_departmentapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeDepartmentAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
